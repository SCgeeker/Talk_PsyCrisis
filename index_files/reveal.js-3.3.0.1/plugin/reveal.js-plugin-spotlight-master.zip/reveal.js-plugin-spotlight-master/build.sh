 #!/bin/sh

REVEAL_PLUGIN_FOLDER=../reveal.js/plugin/spotlight

mkdir -p ${REVEAL_PLUGIN_FOLDER}
cp spotlight.js ${REVEAL_PLUGIN_FOLDER}/spotlight.js
